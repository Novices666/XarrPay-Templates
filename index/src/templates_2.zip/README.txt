上传到
项目根目录/templates/index/自己命名模板名称

商户版后台--系统设置--基础信息

首页类型选择--自定义模板
首页模板--填写  自己命名模板名称

若没有样式

可能是忘了关键字替换

在宝塔中打开index.html

ctrl+h替换

第一行--assets
第二行--${.templateAssets}